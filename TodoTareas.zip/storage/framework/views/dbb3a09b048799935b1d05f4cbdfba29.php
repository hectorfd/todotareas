<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <div class="card">
                    <div class="card-header">Crear Tarea en la Lista: <?php echo e($taskList->listName); ?></div>

                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('tasks.store', $taskList->id)); ?>">
                            <?php echo csrf_field(); ?>

                            <div class="form-group">
                                <label for="titulo">Tarea</label>
                                <input type="text" name="titulo" class="form-control" required>
                            </div>

                            

                            <div class="form-group">
                                <label for="fecha_vencimiento">Fecha de Vencimiento</label>
                                <input type="datetime-local" name="fecha_vencimiento" class="form-control">
                            </div>

                            

                            <button type="submit" class="btn btn-primary">Crear Tarea</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\TodoTareas\resources\views/tasks/create.blade.php ENDPATH**/ ?>