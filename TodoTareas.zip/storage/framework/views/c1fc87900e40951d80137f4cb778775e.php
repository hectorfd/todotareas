<nav class="navbar navbar-expand- navbar-light bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(url('/dashboard')); ?>">
            <?php echo e(config('app.name', 'TodoList')); ?>

        </a>
        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-danger">Cerrar Sesión</button>
        </form>
    </div>
</nav>

<?php /**PATH C:\laragon\www\TodoTareas\resources\views/layouts/navigation.blade.php ENDPATH**/ ?>