<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <div class="card">
                    <div class="card-header">
                        Tareas Completadas en la Lista: <?php echo e($taskList->listName); ?>

                        <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-primary btn-sm float-right">Volver</a>
                    </div>

                    <div class="card-body">
                        <?php if($completedTasks->isEmpty()): ?>
                            <p>No hay tareas completadas en esta lista.</p>
                        <?php else: ?>
                            <ul class="list-group">
                                <?php $__currentLoopData = $completedTasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        <div>
                                            <strong><?php echo e($task->titulo); ?></strong>
                                            <p><?php echo e($task->descripcion); ?></p>
                                            <small>Completada el: <?php echo e($task->updated_at); ?></small>
                                        </div>
                                        <div>
                                            <form action="<?php echo e(route('tasks.updateStatus', $task->id)); ?>" method="POST" style="display:inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PATCH'); ?>
                                                <div class="form-check">
                                                    <input class="form-check-input cursor-pointer p-2  w-6 h-6 rounded-full border-2 border-gray-300 checked:bg-green-500 checked:border-green-500 focus:ring-0 focus:outline-none" type="checkbox" id="completada-<?php echo e($task->id); ?>" name="completada" onChange="this.form.submit()" <?php echo e($task->completada ? 'checked' : ''); ?>>
                                                    <label class="form-check-label" for="completada-<?php echo e($task->id); ?>">
                                                        <span class="text-gray-50 m-2 badge <?php echo e($task->completada ? 'bg-success' : 'bg-secondary'); ?>">
                                                            <?php echo e($task->completada ? 'Completado' : 'Pendiente'); ?>

                                                        </span>
                                                    </label>
                                                </div>
                                            </form>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\TodoTareas\resources\views/tasks/completed.blade.php ENDPATH**/ ?>