<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div>
                <span class="mr-3 font-bold">Usuario: <?php echo e(Auth::user()->username); ?></span>
                <a href="<?php echo e(route('profile.edit')); ?>" class="btn btn-primary">
                    <i class="fas fa-edit mr-2"></i>Perfil
                </a>
            </div>
            
            <?php if($taskLists->count() == 0): ?>
                <div class="card mt-4">
                    <div class="card-header"> <h2>Crear tu primera lista</h2></div>
                    <div class="card-body">
                        <a href="<?php echo e(route('task_lists.create')); ?>" class="btn btn-primary">Crear lista</a>
                    </div>
                </div>
            <?php endif; ?>
            <?php if($taskLists->count() > 0): ?>
                <div class="card mt-4">
                    <div class="card-header d-flex justify-content-between align-items-center bg-purple-600">
                        <h2 class="mb-0 font-bold text-white">Tus Listas</h2>
                        <div class="justify-content-center">
                            <a href="<?php echo e(route('task_lists.create')); ?>" class="btn btn-primary">Crear lista</a>
                        </div>
                    </div>
                    
                    <div class="card-body">
                        <ul class="list-group">
                            <?php $__currentLoopData = $taskLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $taskList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="list-group-item">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <button class="btn btn-link toggle-tasks" data-target="tasks-<?php echo e($taskList->id); ?>">
                                            <i class="fas fa-tasks mr-2"></i>
                                        </button>
                                        <h4 class="font-bold"><?php echo e($taskList->listName); ?></h4>
                                        <div class="d-flex align-items-center">
                                            <a href="<?php echo e(route('tasks.create', $taskList->id)); ?>" class="btn btn-primary btn-sm">Crear tarea</a>
                                            
                                            <a href="<?php echo e(route('tasks.completed', $taskList->id)); ?>" class="btn btn-success ml-2 btn-sm"><i class="fas fa-check-square mr-0 text-white"></i></a>
                                            
                                            <button class="btn btn-info ml-2 btn-sm" data-toggle="modal" data-target="#editTaskListModal-<?php echo e($taskList->id); ?>"><i class="fas fa-pencil-alt mr-0 text-white"></i></button>
                                            
                                            <form method="POST" action="<?php echo e(route('task_lists.destroy', $taskList->id)); ?>" class="inline-block ml-2 delete-form">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="button" class="btn btn-danger btn-sm delete-btn"><i class="fas fa-trash-alt mr-0 text-white"></i></button>
                                            </form>
                                        </div>
                                    </div>
                                    <ul class="list-group mt-3 tasks-<?php echo e($taskList->id); ?>">
                                        <?php $__currentLoopData = $taskList->tasks->where('completada', 0); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="list-group-item <?php echo e($task->fecha_vencimiento && $task->fecha_vencimiento < now() && !$task->completada ? 'task-vencida' : ''); ?>">
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <div>
                                                        <strong><?php echo e($task->titulo); ?></strong>
                                                        <p><?php echo e($task->descripcion); ?></p>
                                                        <small><?php echo e($task->fecha_vencimiento && $task->fecha_vencimiento < now() && !$task->completada ? 'Vencido' : 'Vence'); ?>: <?php echo e($task->fecha_vencimiento); ?></small>
                                                    </div>
                                                    <div class="d-flex align-items-center">
                                                        <form method="POST" action="<?php echo e(route('tasks.updateStatus', $task->id)); ?>">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('PATCH'); ?>
                                                            <input type="hidden" name="completada" value="0">
                                                            <input type="checkbox" name="completada" value="1" class="form-check-input cursor-pointer p-2 w-6 h-6 rounded-full border-2 border-gray-300 checked:bg-green-500 checked:border-green-500 focus:ring-0 focus:outline-none" <?php echo e($task->completada ? 'checked' : ''); ?> onchange="this.form.submit()">
                                                            <span class="m-2 badge badge-<?php echo e($task->completada ? 'success' : 'secondary'); ?>"><?php echo e($task->completada ? 'Completada' : 'Pendiente'); ?></span>
                                                        </form>
                                                        <button class="btn btn-warning btn-sm ml-2" data-toggle="modal" data-target="#editTaskModal-<?php echo e($task->id); ?>"><i class="far fa-edit mr-0 text-white"></i></button>
                                                        <form method="POST" action="<?php echo e(route('tasks.destroy', $task->id)); ?>" class="ml-2 delete-form">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="button" class="btn btn-danger btn-sm delete-btn"><i class="fas fa-times mr-0 text-white"></i></button>
                                                        </form>
                                                    </div>
                                                </div>
                                                
                                                <?php if($task->subtasks && $task->subtasks->count() > 0): ?>
                                                <ul class="list-group mt-3">
                                                    <?php $__currentLoopData = $task->subtasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subtask): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li class="list-group-item">
                                                            <div class="d-flex justify-content-between align-items-center">
                                                                <div>
                                                                    <strong><?php echo e($subtask->titulo); ?></strong>
                                                                    <form method="POST" action="<?php echo e(route('subtasks.updateStatus', $subtask->id)); ?>">
                                                                        <?php echo csrf_field(); ?>
                                                                        <?php echo method_field('PATCH'); ?>
                                                                        <input type="checkbox" name="completado" value="1" class="form-check-input cursor-pointer p-2  w-6 h-6 rounded-full border-2 border-gray-300 checked:bg-green-500 checked:border-green-500 focus:ring-0 focus:outline-none" <?php echo e($subtask->completado ? 'checked' : ''); ?> onchange="this.form.submit()">
                                                                        <span class="m-2 badge badge-<?php echo e($subtask->completado ? 'success' : 'secondary'); ?>"><?php echo e($subtask->completado ? 'Completada' : 'Pendiente'); ?></span>
                                                                    </form>
                                                                </div>
                                                                <form method="POST" action="<?php echo e(route('subtasks.destroy', $subtask->id)); ?>" class="ml-2 delete-form">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('DELETE'); ?>
                                                                    <button type="button" class="btn btn-danger btn-sm delete-btn"><i class="fas fa-times mr-0 text-white"></i></button>
                                                                </form>
                                                            </div>
                                                        </li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            <?php endif; ?>

                                            
                                            <button class="btn btn-primary btn-sm mt-2" data-toggle="modal" data-target="#createSubtaskModal-<?php echo e($task->id); ?>">Crear subtarea</button>
                                            
                                            
                                            <div class="modal fade" id="createSubtaskModal-<?php echo e($task->id); ?>" tabindex="-1" role="dialog" aria-labelledby="createSubtaskModalLabel-<?php echo e($task->id); ?>" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="createSubtaskModalLabel-<?php echo e($task->id); ?>">Crear Subtarea</h5>
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <form method="POST" action="<?php echo e(route('subtasks.store', $task->id)); ?>">
                                                            <?php echo csrf_field(); ?>
                                                            <div class="modal-body">
                                                                <div class="form-group">
                                                                    <label for="titulo">Título</label>
                                                                    <input type="text" name="titulo" class="form-control" required>
                                                                    <input type="hidden" name="task_id" value="<?php echo e($task->id); ?>">
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                                                                <button type="submit" class="btn btn-primary">Guardar</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
</div>




    <?php $__currentLoopData = $taskLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $taskList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $taskList->tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('tasks.edit-modal', ['task' => $task], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__currentLoopData = $taskLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $taskList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="editTaskListModal-<?php echo e($taskList->id); ?>" tabindex="-1" role="dialog" aria-labelledby="editTaskListModalLabel-<?php echo e($taskList->id); ?>" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editTaskListModalLabel-<?php echo e($taskList->id); ?>">Editar Lista</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form method="POST" action="<?php echo e(route('task_lists.update', $taskList->id)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="listName">Nombre de la Lista</label>
                            <input type="text" class="form-control" id="listName" name="listName" value="<?php echo e($taskList->listName); ?>" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-primary">Guardar cambios</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <script>
        
        document.addEventListener("DOMContentLoaded", function() {
            const toggleButtons = document.querySelectorAll('.toggle-tasks');
            toggleButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const targetId = this.getAttribute('data-target');
                    const targetList = document.querySelector(`.${targetId}`);
                    targetList.classList.toggle('hidden'); 
                });
            });

            const toggleAllListsButton = document.getElementById('toggleAllLists');
            toggleAllListsButton.addEventListener('click', function() {
                const allTaskLists = document.querySelectorAll('.list-group');
                allTaskLists.forEach(list => {
                    list.classList.toggle('hidden'); 
                });
            });
        });
        document.addEventListener("DOMContentLoaded", function() {
        const deleteButtons = document.querySelectorAll('.delete-btn');
        deleteButtons.forEach(button => {
            button.addEventListener('click', function(event) {
                event.preventDefault();
                const form = this.closest('.delete-form');
                
                Swal.fire({
                    title: '¿Estás seguro?',
                    text: "¡Deseas Eliminar!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Sí, eliminar',
                    cancelButtonText: 'Cancelar'
                }).then((result) => {
                    if (result.isConfirmed) {
                        form.submit();
                    }
                });
            });
        });
    });

    </script>

<?php $__env->stopSection(); ?>

















<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\TodoTareas\resources\views/dashboard.blade.php ENDPATH**/ ?>