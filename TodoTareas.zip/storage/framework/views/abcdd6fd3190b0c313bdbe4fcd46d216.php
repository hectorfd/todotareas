<!-- login.blade.php -->
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    

    <title>Login</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    
</head>
<body>
    <div class="min-h-screen flex items-center justify-center">
    <div class="centered-container ">
            
    <form method="POST" action="<?php echo e(route('login')); ?>" class="form-container bg-custom">
        <?php echo csrf_field(); ?>
        <div class="flex items-center justify-center">
        <h2 class="mx-auto mb-4 text-green-400 font-bold">Login</h2>
        </div>
        <img src="<?php echo e(asset('images/mochi.gif')); ?>" alt="Login" class="mx-auto mb-4 w-32  object-cover">
        <div class="form-group">
            <label for="username">Nombre de usuario</label>
            <input id="username" type="text" name="username" value="<?php echo e(old('username')); ?>" required autofocus placeholder="Ingrese su nombre de Usuario">
            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
            <label for="password">Contraseña</label>
            <input id="password" type="password" name="password" placeholder="Ingrese su Contraseña" required>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
            <label for="remember">
                <input type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                Recordarme
            </label>
        </div>
        <div class="flex items-center justify-center">
        <button type="submit" class="mr-4 submit-button">Iniciar sesión</button>
        <a href="<?php echo e(route('register')); ?>" class=" submit-button hover:bg-green-400">Registrarse</a>
        </div>
    </form>
    </div>
</div>
<script>
        
    document.addEventListener('DOMContentLoaded', function() {
        const usernameInput = document.getElementById('username');
        
        usernameInput.addEventListener('input', function() {
            this.value = this.value.toLowerCase().replace(/\s/g, '');
        });
        

        
    });
</script>
</body>
</html>


<?php /**PATH C:\laragon\www\TodoTareas\resources\views/auth/login.blade.php ENDPATH**/ ?>