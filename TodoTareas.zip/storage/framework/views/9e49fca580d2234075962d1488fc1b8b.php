<div class="modal fade" id="editTaskModal-<?php echo e($task->id); ?>" tabindex="-1" role="dialog" aria-labelledby="editTaskModalLabel-<?php echo e($task->id); ?>" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editTaskModalLabel-<?php echo e($task->id); ?>">Editar Tarea</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form method="POST" action="<?php echo e(route('tasks.update', $task->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="titulo">Título</label>
                        <input type="text" class="form-control" id="titulo" name="titulo" value="<?php echo e($task->titulo); ?>">
                    </div>
                    <div class="form-group">
                        <label for="descripcion">Descripción</label>
                        <textarea class="form-control" id="descripcion" name="descripcion"><?php echo e($task->descripcion); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="fecha_vencimiento">Fecha de Vencimiento</label>
                        <input type="datetime-local" class="form-control" id="fecha_vencimiento" name="fecha_vencimiento" value="<?php echo e($task->fecha_vencimiento); ?>">
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Actualizar Tarea</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\TodoTareas\resources\views/tasks/edit-modal.blade.php ENDPATH**/ ?>